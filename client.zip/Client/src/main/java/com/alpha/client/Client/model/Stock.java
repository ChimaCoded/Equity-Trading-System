//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//
//
//public class Stock{
//    @Id
//    @GeneratedValue
//    private Long id;
//    private int quantity;
//    private String ticker;
//    private String portfolioId;
//}
//
//
//
