package com.alpha.client.Client.model;

public class ClientUI {

    private String firstName;
    private String lastName;
    private String password;
    private String emailAddress;
    private double bankBalance;


    public ClientUI() {
    }

    public ClientUI(String firstName, String lastName, String password, String emailAddress, double bankBalance) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.emailAddress = emailAddress;
        this.bankBalance = bankBalance;



    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public double getBankBalance() {
        return bankBalance;
    }

    public void setBankBalance(double bankBalance) {
        this.bankBalance = bankBalance;
    }

    public String toString() {
        return String.format("Client[firstName='%s', lastName='%s', emailAddress='%s', password='%s', bankBalance='%s' ]", firstName, lastName, emailAddress, password, bankBalance);
    }
}


