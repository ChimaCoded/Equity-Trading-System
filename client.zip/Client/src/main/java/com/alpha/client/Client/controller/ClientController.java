package com.alpha.client.Client.controller;

import com.alpha.client.Client.model.Client;
import com.alpha.client.Client.model.ClientUI;
import com.alpha.client.Client.repo.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
public class ClientController {
    @Autowired
    ClientRepository repository;

//    @GetMapping("/bulkcreate")
//    public String bulkcreate(){
//        // save a single Client
//        repository.save(new Client("Chima", "Ibebunjoh", "abc", "pass", 33.0));
//
//        // save a list of Clients
//        repository.saveAll(Arrays.asList(new Client("Vincent", "A", "abc", "2", 143.11)
//                , new Client("Najat", "M", "M", "2", 303.11)
//                , new Client("Kelvin", "Kay", "abc", "2", 473.71)
//                , new Client("Sam", "M", "abc", "2", 923.11)));
//
//        return "Clients are created";
//    }


    @PostMapping("/create")
    public String create(@RequestBody ClientUI client){
        // save a single Client
        repository.save(new Client("Chima", "Ibebunjoh", "abc", "pass", 33.0));

        return "Client is created";
    }

    @GetMapping("/findall")
    public List<ClientUI> findAll(){

        List<Client> clients = repository.findAll();
        List<ClientUI> clientUI = new ArrayList<>();

        for (Client client : clients) {
            clientUI.add(new ClientUI(client.getFirstName(),client.getLastName(), client.getPassword(), client.getEmailAddress(), client.getBankBalance()));
        }

        return clientUI;
    }

    @RequestMapping("/search/{id}")
    public String search(@PathVariable long id){
        String client = "";
        client = repository.findById(id).toString();
        return client;
    }

    @RequestMapping("/searchbyfirstname/{firstname}")
    public List<ClientUI> fetchDataByLastName(@PathVariable String firstname) {

        List<Client> clients = repository.findByFirstName(firstname);
        List<ClientUI> clientUI = new ArrayList<>();

        for (Client client : clients) {
            clientUI.add(new ClientUI(client.getFirstName(), client.getLastName(), client.getPassword(), client.getEmailAddress(), client.getBankBalance()));
            //clientUI.add(new OrderUI(Order.)

        }

        return clientUI;

    }





}