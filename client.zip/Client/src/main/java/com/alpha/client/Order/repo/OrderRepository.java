//package com.alpha.client.repo;
//
//import com.alpha.client.model.Client;
//import com.alpha.client.model.Order;
//import org.springframework.data.repository.CrudRepository;
//
//import java.util.List;
//
//public interface OrderRepository  extends CrudRepository<Order, Long> {
//    List<Client> findByOrderId(String ticker);
//    Iterable<Order> findAllOrders();
//}
//
