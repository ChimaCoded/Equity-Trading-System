//package com.alpha.client.validator;
//
//public class ClientOrderValidation {
//    private long clientID;
//    private double orderValue;
//
//    public ClientOrderValidation() {}
//
//    public ClientOrderValidation(long id,double value) {
//        this.clientID = id;
//        this.orderValue = value;
//    }
//
//    public long getClientID() {
//        return clientID;
//    }
//
//    public void setClientID(long clientID) {
//        this.clientID = clientID;
//    }
//
//    public double getOrderValue() {
//        return orderValue;
//    }
//
//    public void setOrderValue(double orderValue) {
//        this.orderValue = orderValue;
//    }
//
//}