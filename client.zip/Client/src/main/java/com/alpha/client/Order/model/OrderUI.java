package com.alpha.client.Order.model;

import java.time.LocalDateTime;

public class OrderUI {
    private long orderId;
    private String ticker;
    private String side;
    private int quantity;
    private double price;
    private LocalDateTime timeStamp;


    public OrderUI() {
    }

    public OrderUI(long orderId, String ticker, String side, int quantity, double price) {
        this.orderId = orderId;
        this.ticker = ticker;
        this.side = side;
        this.quantity = quantity;
        this.price = price;
        this.timeStamp = LocalDateTime.now();
    }


    public long getOrderId() {
        return orderId;
    }

    public void setOrderId(long orderId) {
        this.orderId = orderId;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }


    public String toString() {
        return "OrderUI{" +
                "ticker='" + ticker + '\'' +
                ", side='" + side + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                ", timeStamp=" + timeStamp +
                '}';
    }

}
