//package com.alpha.client.controller;
//
//import com.alpha.client.model.Order;
//import com.alpha.client.model.OrderUI;
//import com.alpha.client.repo.OrderRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@RestController
//public class OrderController {
//
//    @Autowired
//    OrderRepository Ordrepository;
//
//    @PostMapping("/createOrder")
//    public String create(@RequestBody OrderUI order){
//        // save a single Order
//        Ordrepository.save(new Order("TSLA", "BUY", 3, 50.2));
//
//        return "Order is created";
//    }
//
//    @GetMapping("/findallOrder")
//    public List<OrderUI> findAll(){
//
//        List<Order> orders = (List<Order>) Ordrepository.findAll();
//        List<OrderUI> orderUI = new ArrayList<>();
//
//        for (Order order : orders) {
//            orderUI.add(new OrderUI(order.getTicker(), order.getSide(), order.getQuantity(), order.getPrice()));
//        }
//
//        return orderUI;
//    }
//
//
//}
